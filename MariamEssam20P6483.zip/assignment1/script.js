const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul","Aug"
,"Sept", "Oct" , "Nov", "Dec"];
const days = ["Sunday" , "Monday", "Tuesday" , "Wednesday" , "Thursday", "Friday" , "Saturday"];

function printAlert(){
    alert("Press to print");
}

const print = function Print(){
    return "<button style='inset-inline-end: 5; width:100px; height:100px' type='button' onclick='window.print()' onmouseover='printAlert()'>"
    + "<img style='width:70px; height:70px' src='images/print.png'>"+"</button>";
}

const difference =  (x,y) => x-y;


function todate(){
    const d = new Date();
    let br = "<br>";
    let y = d.getFullYear();
    let m = d.getMonth()+1;
    let month = " ("+months[d.getMonth()]+")";
    let date = d.getDay();
    let diwanOpenDate = new Date();
    diwanOpenDate.setFullYear(2002);
    diwanOpenDate.setMonth(6);
    let years = difference(d.getFullYear(),diwanOpenDate.getFullYear());
    {
        let years = d.getFullYear() ;

    }
    var yrs = d.getFullYear();
    {
        yrs = difference(d.getFullYear(),diwanOpenDate.getFullYear());
    }


    window.alert(d);
    let text ="<img src='images/date.png' style='float:right;'>"
    + "<br><h3>Year: "+y + br +"Month: "+m +month+ br+
    "Day: "+ d.getDate() + " ("+ days[d.getDay()] + ")"+ br+ 
    "Hours: " +d.getHours() + br + "Minutes: " + d.getMinutes() +
    br + "Seconds: " + d.getSeconds() + br + "Milliseconds: " +
    d.getMilliseconds() + br + "Milliseconds since 1, Jan , 1970: " +
    d.getTime() + br+ br+
    "</h3><hr>" + "<h3>Diwan first opened in : " + 
    (diwanOpenDate.getMonth()+1) + "(" 
    + months[diwanOpenDate.getMonth()]+") "+
    diwanOpenDate.getFullYear() +  "<br>Diwan is " 
    + years + " years old"+ "</h3>"+
    "<h1>"+yrs+" Years 🥳</h1>"+ print()  +
    "<div style='clear:both'></div>" ;
    
    document.write(text);
    // document.write(date);
}

let image = 0;
const images = ["diwan1.jpg", "diwan2.jpg", "diwan3.jpg"]
function changeImage(x) {
    debugger;
    switch (x) {
        case '+':
            if (image + 1 < images.length) {
                image += 1;
            }
            else { image = 0; }
            document.getElementById("main_image").src = 'images/' + images[image];
            console.log(images[image]);

            break;
        case '-':
            if (image - 1 >= 0) {
                image -= 1;
            }
            else { image = images.length - 1; }
            document.getElementById("main_image").src = 'images/' + images[image];
            console.log(images[image]);
            break;

        default:

    }
   
    function goOffline(){
        document.write
    }

}